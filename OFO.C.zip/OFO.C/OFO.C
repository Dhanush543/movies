#include<graphics.h>
#include<stdio.h>
#include<conio.h>
#include<string.h>
int i,choice,n,q,c=0,sum,temp=0;
char ch1,ch,name[30],uid[30],pwd[100],pwd1[100];
void login();
void veg();
void vegrice();
void vegbiryani();
void curdrice();
void tomatorice();
void podinarice();
void fullmeals();
void nonveg();
void dummbiryani();
void muttonbiryani();
void francebiryani();
void chickenbiryani();
void wingsbiryani();
void cancel();
void reg();
int main()
{
clrscr();
printf("\n*******************************************************************************");
printf("\n\t\t\t  *$$ DELICIOUS FOOD COURT $$* ");
printf("\n\t\t\t      easy and fast delivery!  ");
printf("\n press enter to proceed....");
if(getch()==13)
clrscr();
do
{
printf("\n 1.login\t2.reg\t3.exit");
printf("\n enter your choice");
scanf("%d",&choice);
switch(choice)
{
case 1:login();
       break;
case 2:reg();
       break;
case 3:clrscr();
       textcolor(YELLOW);
       cprintf("\n                           #* THANK U VISIT AGAIN *#");
       printf("\n press enter to exit");
       getch();
       break;
default:
       printf("\n invalid choice");
}
}while(choice!=3);
return 1;
}
//---------------------------------------------------------------------------
//                             * LOGIN *
//---------------------------------------------------------------------------
void login()
{
clrscr();
printf("\n enter user-id: ");
scanf("%s",uid);
printf("\n enter password of four characters: ");
for(i=0;i<4;i++)
{
 ch=getch();
 pwd[i]=ch;
 ch='*';
printf("%c",ch);
}
printf("\n press enter to proceed.....");
if(getch()==13)
clrscr();
do
{
printf("\n food menu");
printf("\n 1.veg  2.non-veg  0.cancel");
printf("\n enter your choice");
scanf("%d",&choice);
switch(choice)
{
case 1:veg();
      break;
case 2:nonveg();
      break;
case 0:cancel();
       break;
case 7:clrscr();
       printf("\n TOTAL BILL: %d",temp);
       printf("\n exit menu");
      break;
default:
printf("\n re-enter choice");
}
}while(choice!=7);
getch();
}
void veg()
{
clrscr();
printf("\n1.veg rice\t-150 Rs\n2.veg biryani\t-180 Rs\n3.full meals\t-70 Rs\n4.tomato rice\t-70 Rs\n5.curd rice\t-40 Rs\n6.podina rice\t-80 Rs");
printf("\n enter your choice");
scanf("%d",&choice);
switch(choice)
{
case 1:vegrice();
       break;
case 2:vegbiryani();
       break;
case 3:fullmeals();
       break;
case 4:tomatorice();
       break;
case 5:curdrice();
       break;
case 6:podinarice();
       break;
}
}
void nonveg()
{
clrscr();
printf("\n1.chicken biryani\t-270 Rs\n2.dumm biryani\t\t-300 Rs\n3.mutton biryani\t-450 Rs\n4.france biryani\t-350 Rs\n5.wings biryani\t\t-250 Rs");
printf("\n enter your choice");
scanf("%d",&choice);
switch(choice)
{
case 1:chickenbiryani();
       break;
case 2:dummbiryani();
       break;
case 3:muttonbiryani();
       break;
case 4:francebiryani();
       break;
case 5:wingsbiryani();
       break;
}
}
//---------------------------------------------------------------------------
//                            * REGISTER *
//---------------------------------------------------------------------------
void reg()
{
FILE *fp;
fp=fopen("C:\\OFO.txt","a");
if(fp==NULL)
{
printf("nothing ");
exit(1);
}
printf("\n enter name");
scanf("%s",name);
printf("\n create your password(only 4 characters)");
for(i=0;i<4;i++)
{
ch=getch();
pwd[i]=ch;
ch='*';
printf("%c",ch);
}
printf("\n confirm password");
for(i=0;i<4;i++)
{
ch1=getch();
pwd1[i]=ch1;
ch1='*';
printf("%c",ch1);
}
if(strcmp(pwd,pwd1)==0)
{
printf("\n succesfully registered");
fprintf(fp,"%s",name);
}
else
{
printf("\n password should be equal");
}
getch();
}
void vegrice()
{
printf("\n enter quantity:");
scanf("%d",&q);
printf("\n ordered succesfully");
printf("\n your order will be delivered within 2 hrs");
sum=q*150;
temp=temp+sum;
//printf("\n you have to pay:%d",temp);
printf("\n  7 to exit");
}
void vegbiryani()
{
printf("\n enter quantity");
scanf("%d",&q);
printf("\n ordered succesfully");
printf("\n your order will be delivered within 2 hrs");
sum=q*180;
temp=temp+sum;
//printf("\n you have to pay:%d",temp);
printf("\n  7 exit");
}
void tomatorice()
{
printf("\n enter quantity");
scanf("%d",&q);
printf("\n ordered succesfully");
printf("\n your order will be delivered within 2 hrs");
sum=q*70;
temp=temp+sum;
//printf("\n you have to pay:%d",temp);
printf("\n  7 to exit");
}
void curdrice()
{
printf("\n enter quantity");
scanf("%d",&q);
printf("\n ordered successfully");
printf("\n your order will be delivered within 2 hrs");
sum=q*40;
temp=temp+sum;
//printf("\n you have to pay:%d",temp);
printf("\n  7 to exit");
}
void fullmeals()
{
printf("\n enter quantity");
scanf("%d",&q);
printf("\n ordered succesfully");
printf("\n your order will be delivered within 2 hrs");
sum=q*70;
temp=temp+sum;
//printf("\n you have to pay:%d",temp);
printf("\n  7 to exit");
}
void podinarice()
{
printf("\n enter quantity");
scanf("%d",&q);
printf("\n ordered successfully");
printf("\n your order will be delivered within 2 hrs");
sum=q*80;
temp=temp+sum;
//printf("\n you have to pay:%d",temp);
printf("\n  7 to exit");
}
void chickenbiryani()
{
printf("\n enter quantity");
scanf("%d",&q);
printf("\n oredered successfully");
printf("\n your order will be delivered within 2 hrs");
sum=q*270;
temp=temp+sum;
//printf("\n you have to pay:%d",temp);
printf("\n  7 to exit");
}
void dummbiryani()
{
printf("\n enter quantity");
scanf("%d",&q);
printf("\n ordered successfully");
printf("\n your order will be deliverd within 2 hrs");
sum=q*300;
temp=temp+sum;
//printf("\n you have to pay:%d",temp);
printf("\n  7 to exit");
}
void muttonbiryani()
{
printf("\n enter quantity");
scanf("%d",&q);
printf("\n ordered successfully ");
printf("\n your order will be delivered within 2 hrs");
sum=q*450;
temp=temp+sum;
//printf("\n you have to pay:%d",temp);
printf("\n  7 to exit");
}
void francebiryani()
{
printf("\n enter quantity");
scanf("%d",&q);
printf("\n ordered successfully");
printf("\n your order will be delivered within 2 hrs");
sum=q*350;
temp=temp+sum;
//printf("\n you have to pay:%d",temp);
printf("\n  7 to exit");
}
void wingsbiryani()
{
printf("\n enter quantity");
scanf("%d",&q);
printf("\n ordered succesfully");
printf("\n your order will be delivered in 2 hrs");
sum=q*250;
temp=temp+sum;
//printf("\n you have to pay:%d",temp);
printf("\n  7 to exit");
}
void cancel()
{
temp=0;
printf("\n your order has been cancelled");
printf("\n 7 to exit menue");
}